from django.urls import path
from . import views
#from firstapp import views

#urlpatterns = [
#    path('', views.index, name='index'),
#]
urlpatterns = [
    path("", views.index),
]