from django.db import models
from django.shortcuts import render

#def index(request):
#    return render(request, "index.html", context = {"question": Question()})

class Room(models.Model):

    number = models.CharField(max_length=255)
    id_hotel = models.IntegerField()
    id_room_category = models.IntegerField()
    is_free = models.BooleanField()
    reservation = models.BooleanField()

class RoomsCategory(models.Model):

    naim = models.CharField(max_length=255)
    category = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    price = models.IntegerField()
    #question = models.ForeignKey(Question, on_delete=models.CASCADE)


