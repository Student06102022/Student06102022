#from django.http import HttpResponse
#def index(request):
#    return HttpResponse("Hello, world. You're at the polls index.")
from django.shortcuts import render
from .models import Room
from .models import RoomsCategory

# получаем все объекты
q = Room.objects.all()
print(q.query)
print(q)
for qq in q:
    print(f"{qq.id}.{qq.is_free}.{qq.reservation}")

def index(request):
    #return render(request, "index.html")
    return render(request, "index.html", context = {"rooms": q})
